<?php
namespace MockyMockenstein;

class Stub_Static extends Stub {
    protected $method_type = RUNKIT_ACC_STATIC;
}
