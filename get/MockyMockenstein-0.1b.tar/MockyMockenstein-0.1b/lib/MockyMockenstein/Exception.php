<?php

namespace MockyMockenstein;

class Exception extends \Exception {
}
