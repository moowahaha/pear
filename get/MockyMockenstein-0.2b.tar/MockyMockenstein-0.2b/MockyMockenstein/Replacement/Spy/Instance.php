<?php
namespace MockyMockenstein;

class Replacement_Spy_Instance extends Replacement_Spy {
    protected $stub_class = '\MockyMockenstein\Stub_Instance';
}
