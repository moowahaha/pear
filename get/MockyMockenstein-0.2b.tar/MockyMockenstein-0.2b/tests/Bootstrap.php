<?php

error_reporting(E_ALL | E_STRICT);

require_once 'MockyMockenstein/Loader.php';

$loader = new \MockyMockenstein\Loader;
$loader->register();

