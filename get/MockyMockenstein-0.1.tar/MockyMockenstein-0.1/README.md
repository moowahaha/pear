MockyMockenstein
==================

Another PHP mocking framework. Doesn't do much. Not yet finished.

Prerequisites
---------------

* Install runkit: `sudo pecl install http://github.com/downloads/zenovich/runkit/runkit-1.0.2.tgz`
* Install php-test-helpers: `pear channel-discover pear.phpunit.de && sudo pecl install phpunit/test_helpers`

Running the Tests
-----------------

`phpunit tests/`

