<?php
namespace MockyMockenstein;

abstract class Replacement_Mock_Instance extends Replacement_Mock {
    protected $stub_class = '\MockyMockenstein\Stub_Instance';
}
