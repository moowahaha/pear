<?php
namespace MockyMockenstein;

class Replacement_MonkeyPatch_Instance extends Replacement_MonkeyPatch {
    protected $stub_class = '\MockyMockenstein\Stub_Instance';
}
