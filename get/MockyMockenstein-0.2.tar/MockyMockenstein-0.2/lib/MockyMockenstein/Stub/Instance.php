<?php
namespace MockyMockenstein;

class Stub_Instance extends Stub {
    protected $method_type = RUNKIT_ACC_PUBLIC;
}
